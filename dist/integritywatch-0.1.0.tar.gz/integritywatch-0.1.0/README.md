# IntegrityWatch
A system design to fight back proctored test circumventions

First install the package using `pip install -e .`
Run using `python -m src.vm_detector.main` for VM Detection