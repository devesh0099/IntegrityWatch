#!/usr/bin/env python3
"""
Comprehensive test suite for multi-compositor window enumeration.

Tests:
- Session type detection
- Compositor identification
- Window enumeration for each WM
- Helper functions
- Integration with BrowserTabDetector

Usage:
    python test/test_compositor.py
    python test/test_compositor.py TestSessionDetection
    python test/test_compositor.py TestSessionDetection.test_detect_x11
"""

import sys
import os
import unittest
import json

# ============================================================================
# FIX IMPORT PATH
# ============================================================================

# Get the project root directory (parent of 'test' directory)
test_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(test_dir)

# Add project root to Python path
sys.path.insert(0, project_root)

# Now imports will work
from src.utils.platform.linux import (
    _detect_session_type,
    _is_command_available,
    _run_command,
    enumerate_windows,
    _enumerate_windows_x11,
    _enumerate_windows_gnome,
    _enumerate_windows_kde,
    _enumerate_windows_sway,
    _enumerate_windows_hyprland,
)

# ============================================================================
# TEST: HELPER FUNCTIONS
# ============================================================================

class TestHelperFunctions(unittest.TestCase):
    """Test helper utility functions."""
    
    def test_is_command_available_existing(self):
        """Test detection of existing commands."""
        # 'ls' should exist on all Linux systems
        self.assertTrue(_is_command_available('ls'))
        self.assertTrue(_is_command_available('echo'))
    
    def test_is_command_available_nonexistent(self):
        """Test detection of non-existent commands."""
        self.assertFalse(_is_command_available('nonexistent_command_xyz'))
    
    def test_run_command_success(self):
        """Test running a successful command."""
        success, output = _run_command(['echo', 'hello'])
        
        self.assertTrue(success)
        self.assertIn('hello', output)
    
    def test_run_command_failure(self):
        """Test running a failing command."""
        success, output = _run_command(['ls', '/nonexistent_directory_xyz'])
        
        self.assertFalse(success)
    
    def test_run_command_timeout(self):
        """Test command timeout handling."""
        success, output = _run_command(['sleep', '10'], timeout=1)
        
        self.assertFalse(success)
        self.assertIn('timeout', output.lower())
    
    def test_run_command_not_found(self):
        """Test command not found handling."""
        success, output = _run_command(['nonexistent_command_xyz'])
        
        self.assertFalse(success)
        self.assertIn('not found', output.lower())


# ============================================================================
# TEST: SESSION DETECTION
# ============================================================================

class TestSessionDetection(unittest.TestCase):
    """Test session type and compositor detection."""
    
    def test_detect_session_type_returns_dict(self):
        """Test that session detection returns proper dict."""
        result = _detect_session_type()
        
        self.assertIsInstance(result, dict)
        self.assertIn('session_type', result)
        self.assertIn('compositor', result)
        self.assertIn('desktop_env', result)
        self.assertIn('details', result)
    
    def test_session_type_is_valid(self):
        """Test that detected session type is valid."""
        result = _detect_session_type()
        
        valid_types = ['x11', 'wayland', 'unknown']
        self.assertIn(result['session_type'], valid_types)
    
    def test_compositor_is_string(self):
        """Test that compositor is a string."""
        result = _detect_session_type()
        
        self.assertIsInstance(result['compositor'], str)
    
    def test_details_contains_env_vars(self):
        """Test that details contains environment variables."""
        result = _detect_session_type()
        details = result['details']
        
        self.assertIn('XDG_SESSION_TYPE', details)
        self.assertIn('XDG_CURRENT_DESKTOP', details)
        self.assertIn('DISPLAY', details)
        self.assertIn('WAYLAND_DISPLAY', details)
    
    def test_print_current_session_info(self):
        """Print current session information (not a real test, just info)."""
        result = _detect_session_type()
        
        print("\n" + "="*70)
        print("CURRENT SESSION INFORMATION")
        print("="*70)
        print(f"Session Type: {result['session_type']}")
        print(f"Compositor: {result['compositor']}")
        print(f"Desktop Environment: {result['desktop_env']}")
        print("\nEnvironment Variables:")
        for key, val in result['details'].items():
            val_display = val if val else "(not set)"
            print(f"  {key:30} = {val_display}")
        print("="*70 + "\n")


# ============================================================================
# TEST: WINDOW ENUMERATION - GENERIC
# ============================================================================

class TestWindowEnumeration(unittest.TestCase):
    """Test generic window enumeration."""
    
    def test_enumerate_windows_returns_list(self):
        """Test that enumerate_windows returns a list."""
        windows = enumerate_windows()
        
        self.assertIsInstance(windows, list)
    
    def test_window_object_structure(self):
        """Test that window objects have correct structure."""
        windows = enumerate_windows()
        
        if len(windows) > 0:
            window = windows[0]
            
            self.assertIn('wid', window)
            self.assertIn('title', window)
            self.assertIn('pid', window)
            self.assertIn('compositor', window)
            
            self.assertIsInstance(window['wid'], str)
            self.assertIsInstance(window['title'], str)
            self.assertIsInstance(window['pid'], int)
            self.assertIsInstance(window['compositor'], str)
    
    def test_enumerate_windows_nonzero(self):
        """Test that at least some windows are found."""
        windows = enumerate_windows()
        
        # Should have at least 1 window (the terminal running the test)
        self.assertGreater(len(windows), 0, 
            "No windows found. This test itself should create at least one window.")
    
    def test_print_all_windows(self):
        """Print all detected windows (informational)."""
        windows = enumerate_windows()
        
        print("\n" + "="*70)
        print(f"DETECTED WINDOWS: {len(windows)}")
        print("="*70)
        
        for idx, win in enumerate(windows[:20], 1):  # Show first 20
            print(f"\n[{idx}] {win['compositor']}")
            print(f"    Title: {win['title'][:60]}")
            print(f"    PID:   {win['pid']}")
            print(f"    WID:   {win['wid']}")
        
        if len(windows) > 20:
            print(f"\n... and {len(windows) - 20} more windows")
        
        print("="*70 + "\n")


# ============================================================================
# TEST: X11 SPECIFIC
# ============================================================================

class TestX11Enumeration(unittest.TestCase):
    """Test X11 window enumeration."""
    
    def setUp(self):
        """Check if running on X11."""
        session_info = _detect_session_type()
        self.is_x11 = (session_info['session_type'] == 'x11')
    
    def test_x11_enumeration_if_available(self):
        """Test X11 enumeration if on X11 session."""
        if not self.is_x11:
            self.skipTest("Not running X11 session")
        
        windows = _enumerate_windows_x11()
        
        self.assertIsInstance(windows, list)
        self.assertGreater(len(windows), 0)
        
        if len(windows) > 0:
            self.assertEqual(windows[0]['compositor'], 'x11_wmctrl')
    
    def test_wmctrl_available_on_x11(self):
        """Test that wmctrl is available on X11."""
        if not self.is_x11:
            self.skipTest("Not running X11 session")
        
        has_wmctrl = _is_command_available('wmctrl')
        
        if not has_wmctrl:
            self.fail("X11 session detected but wmctrl not installed. "
                     "Install with: sudo apt install wmctrl")


# ============================================================================
# TEST: GNOME WAYLAND SPECIFIC
# ============================================================================

class TestGnomeEnumeration(unittest.TestCase):
    """Test GNOME Wayland window enumeration."""
    
    def setUp(self):
        """Check if running on GNOME Wayland."""
        session_info = _detect_session_type()
        self.is_gnome = (session_info['compositor'] == 'gnome')
    
    def test_gnome_enumeration_if_available(self):
        """Test GNOME enumeration if on GNOME session."""
        if not self.is_gnome:
            self.skipTest("Not running GNOME Wayland session")
        
        windows = _enumerate_windows_gnome()
        
        self.assertIsInstance(windows, list)
        
        if len(windows) > 0:
            self.assertEqual(windows[0]['compositor'], 'gnome_wayland')
    
    def test_gdbus_available_on_gnome(self):
        """Test that gdbus is available on GNOME."""
        if not self.is_gnome:
            self.skipTest("Not running GNOME Wayland session")
        
        has_gdbus = _is_command_available('gdbus')
        
        if not has_gdbus:
            self.fail("GNOME detected but gdbus not installed. "
                     "Install with: sudo apt install libglib2.0-bin")


# ============================================================================
# TEST: KDE WAYLAND SPECIFIC
# ============================================================================

class TestKdeEnumeration(unittest.TestCase):
    """Test KDE Wayland window enumeration."""
    
    def setUp(self):
        """Check if running on KDE Wayland."""
        session_info = _detect_session_type()
        self.is_kde = (session_info['compositor'] == 'kde')
    
    def test_kde_enumeration_if_available(self):
        """Test KDE enumeration if on KDE session."""
        if not self.is_kde:
            self.skipTest("Not running KDE Wayland session")
        
        windows = _enumerate_windows_kde()
        
        self.assertIsInstance(windows, list)
        
        if len(windows) > 0:
            self.assertEqual(windows[0]['compositor'], 'kde_wayland')
    
    def test_qdbus_available_on_kde(self):
        """Test that qdbus is available on KDE."""
        if not self.is_kde:
            self.skipTest("Not running KDE Wayland session")
        
        has_qdbus = _is_command_available('qdbus')
        
        if not has_qdbus:
            self.fail("KDE detected but qdbus not installed. "
                     "Usually comes with KDE, check your installation.")


# ============================================================================
# TEST: SWAY SPECIFIC
# ============================================================================

class TestSwayEnumeration(unittest.TestCase):
    """Test Sway window enumeration."""
    
    def setUp(self):
        """Check if running on Sway."""
        session_info = _detect_session_type()
        self.is_sway = (session_info['compositor'] == 'sway')
    
    def test_sway_enumeration_if_available(self):
        """Test Sway enumeration if on Sway session."""
        if not self.is_sway:
            self.skipTest("Not running Sway session")
        
        windows = _enumerate_windows_sway()
        
        self.assertIsInstance(windows, list)
        
        if len(windows) > 0:
            self.assertEqual(windows[0]['compositor'], 'sway')
    
    def test_swaymsg_available_on_sway(self):
        """Test that swaymsg is available on Sway."""
        if not self.is_sway:
            self.skipTest("Not running Sway session")
        
        has_swaymsg = _is_command_available('swaymsg')
        
        if not has_swaymsg:
            self.fail("Sway detected but swaymsg not installed. "
                     "Install with: sudo apt install sway")


# ============================================================================
# TEST: HYPRLAND SPECIFIC
# ============================================================================

class TestHyprlandEnumeration(unittest.TestCase):
    """Test Hyprland window enumeration."""
    
    def setUp(self):
        """Check if running on Hyprland."""
        session_info = _detect_session_type()
        self.is_hyprland = (session_info['compositor'] == 'hyprland')
    
    def test_hyprland_enumeration_if_available(self):
        """Test Hyprland enumeration if on Hyprland session."""
        if not self.is_hyprland:
            self.skipTest("Not running Hyprland session")
        
        windows = _enumerate_windows_hyprland()
        
        self.assertIsInstance(windows, list)
        
        if len(windows) > 0:
            self.assertEqual(windows[0]['compositor'], 'hyprland')
    
    def test_hyprctl_available_on_hyprland(self):
        """Test that hyprctl is available on Hyprland."""
        if not self.is_hyprland:
            self.skipTest("Not running Hyprland session")
        
        has_hyprctl = _is_command_available('hyprctl')
        
        if not has_hyprctl:
            self.fail("Hyprland detected but hyprctl not installed. "
                     "Should come with Hyprland installation.")


# ============================================================================
# TEST: BROWSER TAB DETECTION INTEGRATION
# ============================================================================

class TestBrowserDetectionIntegration(unittest.TestCase):
    """Test integration with browser tab detector."""
    
    def test_detect_chrome_windows(self):
        """Test detection of Chrome browser windows."""
        windows = enumerate_windows()
        
        chrome_windows = [
            w for w in windows 
            if 'chrome' in w['title'].lower()
        ]
        
        print(f"\n[INFO] Found {len(chrome_windows)} Chrome windows")
        
        for win in chrome_windows:
            print(f"  - {win['title'][:60]}")
    
    def test_detect_conference_tools(self):
        """Test detection of conference tool windows."""
        windows = enumerate_windows()
        
        conference_keywords = [
            'meet.google.com',
            'zoom.us',
            'teams.microsoft.com',
            'discord.com',
            'presenting',
            'sharing'
        ]
        
        suspicious_windows = []
        
        for win in windows:
            title_lower = win['title'].lower()
            for keyword in conference_keywords:
                if keyword in title_lower:
                    suspicious_windows.append({
                        'window': win,
                        'keyword': keyword
                    })
                    break
        
        print(f"\n[INFO] Found {len(suspicious_windows)} potentially suspicious windows")
        
        for item in suspicious_windows:
            print(f"  - Keyword: '{item['keyword']}'")
            print(f"    Title: {item['window']['title'][:60]}")


# ============================================================================
# TEST: COVERAGE REPORT
# ============================================================================

class TestCoverageReport(unittest.TestCase):
    """Generate coverage report for current system."""
    
    def test_generate_coverage_report(self):
        """Generate comprehensive coverage report."""
        session_info = _detect_session_type()
        windows = enumerate_windows()
        
        print("\n" + "="*70)
        print("SYSTEM COVERAGE REPORT")
        print("="*70)
        
        print(f"\nSession Type: {session_info['session_type']}")
        print(f"Compositor: {session_info['compositor']}")
        print(f"Desktop: {session_info['desktop_env']}")
        
        print(f"\nWindows Detected: {len(windows)}")
        
        # Check available tools
        print("\nAvailable Tools:")
        tools = {
            'wmctrl': 'X11 enumeration',
            'xdotool': 'X11 fallback',
            'gdbus': 'GNOME Wayland',
            'qdbus': 'KDE Wayland',
            'swaymsg': 'Sway',
            'hyprctl': 'Hyprland',
        }
        
        for tool, description in tools.items():
            available = _is_command_available(tool)
            status = "✓ Installed" if available else "✗ Not installed"
            print(f"  {tool:15} ({description:20}) - {status}")
        
        # Determine coverage
        print("\nDetection Coverage:")
        
        if session_info['session_type'] == 'x11':
            if _is_command_available('wmctrl'):
                print("  ✓ FULL COVERAGE - X11 with wmctrl")
            else:
                print("  ✗ NO COVERAGE - Install wmctrl")
        
        elif session_info['session_type'] == 'wayland':
            compositor = session_info['compositor']
            
            if compositor == 'gnome':
                if _is_command_available('gdbus'):
                    print("  ✓ FULL COVERAGE - GNOME Wayland with gdbus")
                else:
                    print("  ✗ NO COVERAGE - Install gdbus (libglib2.0-bin)")
            
            elif compositor == 'kde':
                if _is_command_available('qdbus'):
                    print("  ✓ FULL COVERAGE - KDE Wayland with qdbus")
                else:
                    print("  ✗ NO COVERAGE - qdbus usually comes with KDE")
            
            elif compositor == 'sway':
                if _is_command_available('swaymsg'):
                    print("  ✓ FULL COVERAGE - Sway with swaymsg")
                else:
                    print("  ✗ NO COVERAGE - swaymsg should come with Sway")
            
            elif compositor == 'hyprland':
                if _is_command_available('hyprctl'):
                    print("  ✓ FULL COVERAGE - Hyprland with hyprctl")
                else:
                    print("  ✗ NO COVERAGE - hyprctl should come with Hyprland")
            
            else:
                print(f"  ⚠ UNKNOWN COMPOSITOR - {compositor}")
                print("    Window enumeration may not work")
        
        else:
            print("  ✗ UNKNOWN SESSION TYPE")
        
        print("\nRecommendations:")
        
        if session_info['session_type'] == 'x11' and not _is_command_available('wmctrl'):
            print("  → Install wmctrl: sudo apt install wmctrl")
        
        elif session_info['session_type'] == 'wayland':
            if session_info['compositor'] == 'gnome' and not _is_command_available('gdbus'):
                print("  → Install gdbus: sudo apt install libglib2.0-bin")
        
        print("="*70 + "\n")


# ============================================================================
# MAIN TEST RUNNER
# ============================================================================

if __name__ == '__main__':
    # Run tests with verbose output
    unittest.main(verbosity=2)
