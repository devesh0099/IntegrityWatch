import sys
from pathlib import Path

# Add src/ directory to Python path
project_root = Path(__file__).parent.parent
src_path = project_root / 'src'
sys.path.insert(0, str(src_path))

# Now imports work (from src/)
from vm_detector.detectors.hardware.firmware.smbios_tables import SMBIOSDetector
from utils.logger import setup_logging

setup_logging('DEBUG')

detector = SMBIOSDetector()
result = detector.safe_detect()

print("\n" + "="*60)
print(f"Detector: {result.name}")
print(f"Detected: {result.detected}")
print(f"Details: {result.details}")
if result.error:
    print(f"Error: {result.error}")
print("="*60)
