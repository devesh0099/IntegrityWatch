# test/test_virtual_registry.py
import sys
sys.path.insert(0, 'src')

def test_platform_function():
    """Test platform layer separately"""
    from vm_detector.platform.windows import get_registry_object_path
    
    print("Testing platform function (data gathering only):")
    print("=" * 70)
    
    path = r'\REGISTRY\USER'
    result = get_registry_object_path(path)
    
    print(f"Queried path: {path}")
    print(f"Returned path: {result}")
    print(f"Result type: {type(result)}")
    
    # No detection logic here - just raw data
    
def test_detector():
    """Test detector (detection logic)"""
    from vm_detector.detectors.sandbox.virtual_registry import VirtualRegistryDetector
    
    print("\nTesting detector (detection logic):")
    print("=" * 70)
    
    detector = VirtualRegistryDetector()
    result = detector.safe_detect()
    
    print(f"Detected: {result.detected}")
    print(f"Details: {result.details}")
    if result.error:
        print(f"Error: {result.error}")

if __name__ == "__main__":
    test_platform_function()
    test_detector()
