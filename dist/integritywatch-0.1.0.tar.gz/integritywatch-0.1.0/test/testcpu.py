#!/usr/bin/env python3
import platform

print("=== System Information ===")
print(f"OS: {platform.system()}")
print(f"Platform: {platform.platform()}")

if platform.system() == "Windows":
    try:
        import wmi
        c = wmi.WMI()
        
        print("\n=== Win32_ComputerSystem ===")
        for sys in c.Win32_ComputerSystem():
            print(f"Manufacturer: {sys.Manufacturer}")
            print(f"Model: {sys.Model}")
            print(f"SystemFamily: {sys.SystemFamily}")
        
        print("\n=== Win32_BIOS ===")
        for bios in c.Win32_BIOS():
            print(f"Manufacturer: {bios.Manufacturer}")
            print(f"Version: {bios.Version}")
            print(f"SerialNumber: {bios.SerialNumber}")
        
        print("\n=== Win32_BaseBoard ===")
        for board in c.Win32_BaseBoard():
            print(f"Manufacturer: {board.Manufacturer}")
            print(f"Product: {board.Product}")
    except Exception as e:
        print(f"WMI Error: {e}")

elif platform.system() == "Linux":
    import subprocess
    
    print("\n=== DMI Decode ===")
    try:
        result = subprocess.run(['sudo', 'dmidecode', '-t', 'system'], 
                               capture_output=True, text=True)
        print(result.stdout)
    except:
        print("dmidecode not available")
    
    print("\n=== systemd-detect-virt ===")
    try:
        result = subprocess.run(['systemd-detect-virt'], 
                               capture_output=True, text=True)
        print(f"Result: {result.stdout.strip()}")
        print(f"Exit code: {result.returncode}")
    except:
        print("systemd-detect-virt not available")


