#!/usr/bin/env python3
"""
Comprehensive CPUID Detection Test Suite

Tests both CPUID vendor string and hypervisor bit detection.
Also tests the underlying platform functions directly.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))  # ← Remove this

from vm_detector.detectors.hardware.cpu.vmid import CPUIDVendorDetector
from vm_detector.detectors.hardware.cpu.hypervisor_bit import HypervisorBitDetector
from utils.logger import setup_logging


def print_header(title: str, char: str = "="):
    """Print formatted section header"""
    width = 70
    print(f"\n{char * width}")
    print(f"{title:^{width}}")
    print(f"{char * width}\n")


def test_platform_functions():
    """Test platform/cpu.py functions directly"""
    print_header("TESTING PLATFORM LAYER (RAW CPUID DATA)", "=")
    
    try:
        from vm_detector.platform import base
        import struct
        
        # Test 1: CPUID leaf 0 (CPU vendor)
        print("Test 1: CPUID Leaf 0 (Basic CPU Vendor)")
        vendor = base.get_cpuid_vendor(0)
        if vendor:
            print(f"  ✓ CPU Vendor: '{vendor}'")
        else:
            print(f"  ✗ Could not read CPU vendor")
        
        # Test 2: CPUID leaf 1 (Features)
        print("\nTest 2: CPUID Leaf 1 (CPU Features)")
        features = base.get_cpuid_features()
        if features:
            ecx = features.get('ecx', 0)
            hypervisor_bit = (ecx >> 31) & 1
            print(f"  ECX register: 0x{ecx:08X}")
            print(f"  Hypervisor bit (bit 31): {hypervisor_bit}")
            if hypervisor_bit:
                print(f"  ⚠ Hypervisor present!")
            else:
                print(f"  ✓ No hypervisor (bare metal)")
        else:
            print(f"  ✗ Could not read features")
        
        # Test 3: CPUID leaf 0x40000000 (Hypervisor vendor)
        print("\nTest 3: CPUID Leaf 0x40000000 (Hypervisor Vendor)")
        hv_vendor = base.get_cpuid_vendor(0x40000000)
        if hv_vendor and hv_vendor.strip():
            print(f"  ✓ Hypervisor Vendor: '{hv_vendor}'")
            print(f"  ⚠ This is a VM!")
        else:
            print(f"  ✓ No hypervisor vendor string (bare metal or hidden)")
        
        # Test 4: Raw registers
        print("\nTest 4: Raw CPUID Registers (Leaf 0x40000000)")
        eax, ebx, ecx, edx = base.get_cpuid_registers(0x40000000)
        print(f"  EAX: 0x{eax:08X}  (max hypervisor leaf)")
        print(f"  EBX: 0x{ebx:08X}  (vendor bytes 0-3)")
        print(f"  ECX: 0x{ecx:08X}  (vendor bytes 4-7)")
        print(f"  EDX: 0x{edx:08X}  (vendor bytes 8-11)")
        
        # Decode manually
        vendor_bytes = struct.pack('<III', ebx, ecx, edx)
        vendor_manual = vendor_bytes.decode('ascii', errors='replace').rstrip('\x00')
        if vendor_manual.strip():
            print(f"  Manual decode: '{vendor_manual}'")
        
    except ImportError as e:
        print(f"✗ ERROR: {e}")
        print("  Is the 'cpuid' library installed?")
        print("  Install with: pip install cpuid")
    except Exception as e:
        print(f"✗ ERROR: {e}")
        import traceback
        traceback.print_exc()


def test_detector(detector_class, detector_name):
    """Test a detector class"""
    print_header(f"TESTING {detector_name}", "=")
    
    detector = detector_class()
    print(f"Detector Name: {detector.name}")
    print(f"Platforms: {detector.supported_platforms}")
    print(f"Requires Admin: {detector.requires_admin}")
    
    print("\n" + "-" * 70)
    print("Running detection...")
    print("-" * 70 + "\n")
    
    result = detector.safe_detect()
    
    print("-" * 70)
    print("RESULT")
    print("-" * 70)
    print(f"Detected: {result.detected}")
    print(f"Details: {result.details}")
    if result.error:
        print(f"Error: {result.error}")
    
    return result


def display_final_verdict(vendor_result, bit_result):
    """Show combined verdict"""
    print_header("FINAL VERDICT", "=")
    
    if bit_result.detected or vendor_result.detected:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│                   🚨  VM DETECTED  🚨                       │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print("\nDetection Evidence:")
        if bit_result.detected:
            print(f"  ✓ {bit_result.details}")
        if vendor_result.detected:
            print(f"  ✓ {vendor_result.details}")
    else:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│              ✓  CLEAN SYSTEM (BARE METAL)  ✓                │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print("\nNo virtualization detected via CPUID checks.")


def main():
    """Main test execution"""
    print("\n")
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║                                                               ║")
    print("║          CPUID-BASED VM DETECTION TEST SUITE                  ║")
    print("║                 IntegrityWatch Project                        ║")
    print("║                                                               ║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    
    # Setup debug logging
    setup_logging(level='DEBUG')
    
    try:
        # Test 1: Platform functions
        test_platform_functions()
        
        # Test 2: Hypervisor bit detector
        bit_result = test_detector(HypervisorBitDetector, "HYPERVISOR BIT DETECTOR")
        
        # Test 3: Vendor string detector
        vendor_result = test_detector(CPUIDVendorDetector, "CPUID VENDOR DETECTOR")
        
        # Final verdict
        display_final_verdict(vendor_result, bit_result)
        
        # Exit code
        sys.exit(0 if not (bit_result.detected or vendor_result.detected) else 1)
        
    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
        sys.exit(2)
    except Exception as e:
        print(f"\n\n✗ FATAL ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(3)


if __name__ == '__main__':
    main()
