import sys
sys.path.insert(0, 'src')

from vm_detector.detectors.hardware.firmware.pci_devices import PCIDetector
from utils.logger import setup_logging

def print_header(title: str, char: str = "="):
    """Print a formatted section header"""
    width = 70
    print(f"\n{char * width}")
    print(f"{title:^{width}}")
    print(f"{char * width}\n")

def test_pci_detection():
    """Test the PCIDetector"""
    print_header("TESTING SMBIOS DETECTOR", "=")
    
    # Setup logging to see debug output
    setup_logging(level='DEBUG')
    
    print("Initializing detector...")
    detector = PCIDetector()
    print(f"  Name: {detector.name}")
    print(f"  Supported Platforms: {detector.supported_platforms}")
    print(f"  Requires Admin: {detector.requires_admin}")
    
    print("\n" + "-" * 70)
    print("Running detection...")
    print("-" * 70 + "\n")
    
    # Run detection
    result = detector.safe_detect()
    
    print("\n" + "-" * 70)
    print("DETECTION COMPLETE")
    print("-" * 70 + "\n")
    
    # Display results
    print(f"Detector Name:   {result.name}")
    print(f"VM Detected:     {result.detected}")
    print(f"Details:         {result.details}")
    if result.error:
        print(f"Error:           {result.error}")
    
    return result


if __name__ == "__main__":
    test_pci_detection()
