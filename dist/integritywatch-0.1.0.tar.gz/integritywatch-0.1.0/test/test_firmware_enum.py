import sys
from pathlib import Path

# Add src to path so we can import vm_detector
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from vm_detector.platform.windows import enumerate_firmware_tables

def dword_to_string(dword: int) -> str:
    """Convert DWORD back to 4-char ASCII string (for display)"""
    import struct
    try:
        # Reverse the big-endian conversion
        bytes_val = struct.pack('>I', dword)
        return bytes_val.decode('ascii', errors='replace')
    except:
        return "????"

def main():
    print("=== Testing ACPI Table Enumeration ===\n")
    
    # Test ACPI provider
    table_ids = enumerate_firmware_tables('ACPI')
    
    if not table_ids:
        print("ERROR: No tables found or enumeration failed")
        print("Are you running on Windows?")
        return
    
    print(f"Found {len(table_ids)} ACPI tables:\n")
    
    for i, table_id in enumerate(table_ids):
        # Show both hex and ASCII representation
        ascii_sig = dword_to_string(table_id)
        print(f"  {i+1}. ID: 0x{table_id:08X}  ASCII: '{ascii_sig}'")
    
    # Check for HPET table (used in VMAware detection)
    HPET_SIG = 0x48504554  # 'HPET' 
    if HPET_SIG in table_ids:
        print("\n HPET table found (typical on real hardware)")
    else:
        print("\n HPET table NOT found (may indicate VM)")

if __name__ == '__main__':
    main()
