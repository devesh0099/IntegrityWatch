import sys
sys.path.insert(0, 'src')

from vm_detector.detectors.hardware.firmware.kernel_objects import KernelObjectDetector

def test_kernel_objects():
    detector = KernelObjectDetector()
    
    if not detector.is_platform_supported():
        print(f"❌ Platform not supported: {detector._current_platform}")
        return
    
    print(f"Platform: {detector._current_platform}")
    print(f"Testing: {detector.name}")
    print("=" * 60)
    
    result = detector.safe_detect()
    
    print(f"Detected: {result.detected}")
    print(f"Details: {result.details}")
    if result.error:
        print(f"Error: {result.error}")
    
    # Manual test of specific paths (for debugging)
    print("\nManual path checks:")
    test_paths = [
        r'\Device\VBoxGuest',
        r'\Driver\VBoxDrv',
        r'\Device\VmGenerationCounter',
        r'\Driver\vmbus',
    ]
    
    from vm_detector.platform.windows import check_kernel_object
    for path in test_paths:
        exists = check_kernel_object(path)
        status = "✓ Found" if exists else "✗ Not found"
        print(f"  {status}: {path}")

if __name__ == "__main__":
    test_kernel_objects()
