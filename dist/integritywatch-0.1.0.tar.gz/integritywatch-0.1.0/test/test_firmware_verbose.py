#!/usr/bin/env python3
"""
Comprehensive Firmware Detection Test Script
Tests the SMBIOSDetector with verbose output and diagnostics
"""

import sys
from pathlib import Path
import platform

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from vm_detector.detectors.hardware.firmware.smbios_tables import SMBIOSDetector
from utils.logger import setup_logging


def print_header(title: str, char: str = "="):
    """Print a formatted section header"""
    width = 70
    print(f"\n{char * width}")
    print(f"{title:^{width}}")
    print(f"{char * width}\n")


def print_system_info():
    """Display system information"""
    print_header("SYSTEM INFORMATION", "=")
    
    print(f"OS:              {platform.system()}")
    print(f"OS Version:      {platform.version()}")
    print(f"OS Release:      {platform.release()}")
    print(f"Architecture:    {platform.machine()}")
    print(f"Processor:       {platform.processor()}")
    print(f"Python Version:  {sys.version.split()[0]}")
    print(f"Python Path:     {sys.executable}")
    
    # Check if running in VM (basic check)
    if platform.system() == 'Windows':
        try:
            import wmi
            c = wmi.WMI()
            system = c.Win32_ComputerSystem()[0]
            print(f"\nSystem Manufacturer: {system.Manufacturer}")
            print(f"System Model:        {system.Model}")
        except:
            pass


def test_platform_functions():
    """Test the underlying platform functions directly"""
    print_header("TESTING PLATFORM LAYER", "=")
    
    if platform.system() == 'Windows':
        from vm_detector.platform import windows
        
        # Test 1: Enumerate ACPI tables
        print("Test 1: Enumerating ACPI Tables...")
        try:
            acpi_ids = windows.enumerate_firmware_tables('ACPI')
            if acpi_ids:
                print(f"  ✓ SUCCESS: Found {len(acpi_ids)} ACPI table IDs")
                
                # Show first 5 tables
                print(f"\n  First 5 ACPI Tables:")
                import struct
                for i, table_id in enumerate(acpi_ids[:5]):
                    # Convert to ASCII signature
                    sig_bytes = struct.pack('>I', table_id)
                    sig_str = sig_bytes.decode('ascii', errors='replace')
                    print(f"    {i+1}. ID: 0x{table_id:08X}  Signature: '{sig_str}'")
                
                # Check for HPET
                HPET_SIG = 0x54455048
                if HPET_SIG in acpi_ids:
                    print(f"\n  ✓ HPET table found (typical on bare metal)")
                else:
                    print(f"\n  ⚠ HPET table NOT found (may indicate VM)")
            else:
                print(f"  ✗ FAILED: No ACPI tables enumerated")
        except Exception as e:
            print(f"  ✗ ERROR: {e}")
        
        # Test 2: Enumerate SMBIOS tables
        print("\n\nTest 2: Enumerating SMBIOS (RSMB) Tables...")
        try:
            rsmb_ids = windows.enumerate_firmware_tables('RSMB')
            if rsmb_ids:
                print(f"  ✓ SUCCESS: Found {len(rsmb_ids)} SMBIOS table IDs")
            else:
                print(f"  ℹ INFO: No SMBIOS tables (not always available)")
        except Exception as e:
            print(f"  ✗ ERROR: {e}")
        
        # Test 3: Fetch a sample table
        print("\n\nTest 3: Fetching Sample ACPI Table...")
        if acpi_ids:
            try:
                sample_id = acpi_ids[0]
                table_data = windows.fetch_firmware_table('ACPI', sample_id)
                if table_data:
                    print(f"  ✓ SUCCESS: Fetched {len(table_data)} bytes")
                    
                    # Show header
                    sig_bytes = struct.pack('>I', sample_id)
                    sig_str = sig_bytes.decode('ascii', errors='replace')
                    print(f"  Table Signature: '{sig_str}'")
                    print(f"  First 32 bytes (hex):")
                    hex_str = ' '.join(f'{b:02X}' for b in table_data[:32])
                    print(f"    {hex_str}")
                else:
                    print(f"  ✗ FAILED: Could not fetch table data")
            except Exception as e:
                print(f"  ✗ ERROR: {e}")
        
        # Test 4: WMI Fallback
        print("\n\nTest 4: Testing WMI Fallback...")
        try:
            firmware_info = windows.get_firmware_info()
            if 'error' in firmware_info:
                print(f"  ✗ ERROR: {firmware_info['error']}")
            else:
                print(f"  ✓ SUCCESS: Retrieved firmware info via WMI")
                for key, value in firmware_info.items():
                    print(f"    {key}: {value}")
        except Exception as e:
            print(f"  ✗ ERROR: {e}")
    
    elif platform.system() == 'Linux':
        print("Linux platform detected - checking ACPI path...")
        import os
        acpi_path = '/sys/firmware/acpi/tables/'
        if os.path.exists(acpi_path):
            files = [f for f in os.listdir(acpi_path) if f not in ['.', '..', 'dynamic']]
            print(f"  ✓ Found {len(files)} ACPI table files:")
            for f in files[:10]:  # Show first 10
                print(f"    - {f}")
        else:
            print(f"  ✗ ACPI path not found: {acpi_path}")


def test_detector():
    """Test the SMBIOSDetector"""
    print_header("TESTING SMBIOS DETECTOR", "=")
    
    # Setup logging to see debug output
    setup_logging(level='DEBUG')
    
    print("Initializing detector...")
    detector = SMBIOSDetector()
    print(f"  Name: {detector.name}")
    print(f"  Supported Platforms: {detector.supported_platforms}")
    print(f"  Requires Admin: {detector.requires_admin}")
    
    print("\n" + "-" * 70)
    print("Running detection...")
    print("-" * 70 + "\n")
    
    # Run detection
    result = detector.safe_detect()
    
    print("\n" + "-" * 70)
    print("DETECTION COMPLETE")
    print("-" * 70 + "\n")
    
    # Display results
    print(f"Detector Name:   {result.name}")
    print(f"VM Detected:     {result.detected}")
    print(f"Details:         {result.details}")
    if result.error:
        print(f"Error:           {result.error}")
    
    return result


def display_verdict(result):
    """Display final verdict with visual indicator"""
    print_header("FINAL VERDICT", "=")
    
    if result.detected:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│                   🚨  VM DETECTED  🚨                       │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print(f"\nReason: {result.details}")
    else:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│              ✓  CLEAN SYSTEM (BARE METAL)  ✓               │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print(f"\nDetails: {result.details}")


def main():
    """Main test execution"""
    print("\n")
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║                                                               ║")
    print("║        FIRMWARE-BASED VM DETECTION TEST SUITE                ║")
    print("║                 IntegrityWatch Project                        ║")
    print("║                                                               ║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    
    try:
        # Step 1: System Info
        print_system_info()
        
        # Step 2: Platform Layer Tests
        test_platform_functions()
        
        # Step 3: Detector Test
        result = test_detector()
        
        # Step 4: Final Verdict
        display_verdict(result)
        
        # Exit code
        sys.exit(0 if not result.detected else 1)
        
    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
        sys.exit(2)
    except Exception as e:
        print(f"\n\n✗ FATAL ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(3)


if __name__ == '__main__':
    main()
