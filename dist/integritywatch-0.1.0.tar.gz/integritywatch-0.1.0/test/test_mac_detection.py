#!/usr/bin/env python3
"""
MAC Address Detection Test Suite

Tests MAC address enumeration and VM vendor prefix matching.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from vm_detector.detectors.hardware.network.mac_address import MACAddressDetector, VM_MAC_PREFIXES
from utils.logger import setup_logging


def print_header(title: str, char: str = "="):
    """Print formatted section header"""
    width = 70
    print(f"\n{char * width}")
    print(f"{title:^{width}}")
    print(f"{char * width}\n")


def test_platform_functions():
    """Test platform layer MAC address enumeration"""
    print_header("TESTING PLATFORM LAYER (MAC ADDRESS ENUMERATION)", "=")
    
    try:
        from vm_detector.platform import base
        
        print("Test: Enumerating MAC addresses...")
        mac_addresses = base.get_mac_addresses()
        
        if mac_addresses:
            print(f"  ✓ Found {len(mac_addresses)} network interfaces:\n")
            for i, mac in enumerate(mac_addresses, 1):
                oui = mac[:8]
                vendor_name = VM_MAC_PREFIXES.get(oui, "Unknown/Bare Metal")
                status = "⚠️ VM" if oui in VM_MAC_PREFIXES else "✓ Clean"
                print(f"    {i}. {mac}")
                print(f"       OUI: {oui}")
                print(f"       Vendor: {vendor_name}")
                print(f"       Status: {status}\n")
        else:
            print("  ✗ No MAC addresses found (error or no interfaces)")
        
    except Exception as e:
        print(f"✗ ERROR: {e}")
        import traceback
        traceback.print_exc()


def test_known_prefixes():
    """Display known VM MAC prefixes"""
    print_header("KNOWN VM MAC PREFIXES DATABASE", "=")
    
    print(f"Total VM vendors tracked: {len(VM_MAC_PREFIXES)}\n")
    
    # Group by vendor
    vendors = {}
    for oui, vendor in VM_MAC_PREFIXES.items():
        if vendor not in vendors:
            vendors[vendor] = []
        vendors[vendor].append(oui)
    
    for vendor in sorted(vendors.keys()):
        ouis = vendors[vendor]
        print(f"{vendor}:")
        for oui in sorted(ouis):
            print(f"  - {oui}")
        print()


def test_detector():
    """Test the MAC address detector"""
    print_header("TESTING MAC ADDRESS DETECTOR", "=")
    
    detector = MACAddressDetector()
    print(f"Detector Name: {detector.name}")
    print(f"Platforms: {detector.supported_platforms}")
    print(f"Requires Admin: {detector.requires_admin}")
    
    print("\n" + "-" * 70)
    print("Running detection...")
    print("-" * 70 + "\n")
    
    result = detector.safe_detect()
    
    print("-" * 70)
    print("RESULT")
    print("-" * 70)
    print(f"Detected: {result.detected}")
    print(f"Details: {result.details}")
    if result.error:
        print(f"Error: {result.error}")
    
    return result


def display_final_verdict(result):
    """Show combined verdict"""
    print_header("FINAL VERDICT", "=")
    
    if result.detected:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│                   🚨  VM DETECTED  🚨                       │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print(f"\nReason: {result.details}")
    else:
        print("┌─────────────────────────────────────────────────────────────┐")
        print("│                                                             │")
        print("│              ✓  CLEAN SYSTEM (BARE METAL)  ✓               │")
        print("│                                                             │")
        print("└─────────────────────────────────────────────────────────────┘")
        print(f"\nDetails: {result.details}")


def main():
    """Main test execution"""
    print("\n")
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║                                                               ║")
    print("║         MAC ADDRESS-BASED VM DETECTION TEST SUITE            ║")
    print("║                 IntegrityWatch Project                        ║")
    print("║                                                               ║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    
    # Setup debug logging
    setup_logging(level='DEBUG')
    
    try:
        # Test 1: Platform functions
        test_platform_functions()
        
        # Test 2: Show known prefixes
        test_known_prefixes()
        
        # Test 3: Run detector
        result = test_detector()
        
        # Final verdict
        display_final_verdict(result)
        
        # Exit code
        sys.exit(0 if not result.detected else 1)
        
    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
        sys.exit(2)
    except Exception as e:
        print(f"\n\n✗ FATAL ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(3)


if __name__ == '__main__':
    main()
